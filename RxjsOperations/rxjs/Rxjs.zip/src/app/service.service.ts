import { Injectable, Input } from '@angular/core';
import { Observable, Observer } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  testObservable$: Observable<any> 
  testobserver: any; 
  
  

  constructor() { 
  this.testObservable$ = new Observable((observer) =>{
    this.testobserver= observer;
  })
  }
}
