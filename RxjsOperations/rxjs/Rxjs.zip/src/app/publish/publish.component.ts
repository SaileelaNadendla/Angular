import { Component, OnInit } from '@angular/core';
import {  of } from 'rxjs';
import {map} from 'rxjs/operators'
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-publish',
  templateUrl: './publish.component.html',
  styleUrls: ['./publish.component.scss']
})
export class PublishComponent implements OnInit {
  source: any;
  source1: any;
  
  

  constructor(private service: ServiceService) { }
  publishData(data: any){
    this.service.testobserver.next(Math.random());
  }

  ngOnInit(){
    //rxjs operators
    
    const source=of({name:'sai'},[1,2,3],
                  function Operations(){
                    return "hello";
                  });
    const subscribe=source.subscribe(val=>console.log(val));
                  
    
    
    
  }
      
    

      
    

   }



