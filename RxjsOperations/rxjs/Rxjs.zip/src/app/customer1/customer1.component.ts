import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-customer1',
  templateUrl: './customer1.component.html',
  styleUrls: ['./customer1.component.scss']
})
export class Customer1Component implements OnInit {
  data: any;
  

  constructor(private service:ServiceService) { }

  ngOnInit(): void {
  }
  getCustomer(){
    this.service.testObservable$.subscribe((data) =>{
      this.data = data+""+new Date().toDateString();
    })
  }

}
