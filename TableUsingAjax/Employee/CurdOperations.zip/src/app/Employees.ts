
export class Employees{
    id:string;
    firstName: string;
    lastName: string;
    Email:string;
    Mobile:string;


    constructor(id:string, firstName:string, lastName:string, Email:string, Mobile:string){
        this.id=id;
        this.firstName=firstName;
        this.lastName=lastName;
        this.Email=Email;
        this.Mobile=Mobile;
    }
}
