import { Data } from "@angular/router";

export class Employee{
    id!:number;
    name!:string;
    salary!:number;
    Dob!:Data;

    
}